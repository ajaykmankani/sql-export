

CREATE TABLE `drive_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `google_drive_file_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


INSERT INTO drive_files VALUES
("1","about_img.webp","","2022-05-26 10:22:26"),
("2","about_img.webp","","2022-05-26 11:32:04"),
("3","","","2022-05-27 12:06:36"),
("4","test___(08-37-07_27-05-2022)__rand5609675.sql","","2022-05-27 12:07:07"),
("5","test___(08-38-26_27-05-2022)__rand1703933.sql","","2022-05-27 12:08:26"),
("6","test___(08-38-27_27-05-2022)__rand742303.sql","","2022-05-27 12:08:27"),
("7","test___(08-38-27_27-05-2022)__rand8481363.sql","","2022-05-27 12:08:27"),
("8","test___(08-38-28_27-05-2022)__rand2494761.sql","","2022-05-27 12:08:28"),
("9","test___(08-38-40_27-05-2022)__rand71263.sql","","2022-05-27 12:08:40"),
("10","test___(08-38-41_27-05-2022)__rand528704.sql","","2022-05-27 12:08:41"),
("11","test___(08-38-42_27-05-2022)__rand7072802.sql","","2022-05-27 12:08:42"),
("12","test___(08-39-44_27-05-2022)__rand716592.sql","","2022-05-27 12:09:44"),
("13","test___(08-39-45_27-05-2022)__rand4873282.sql","","2022-05-27 12:09:45"),
("14","test___(08-39-45_27-05-2022)__rand7793090.sql","","2022-05-27 12:09:45"),
("15","test___(08-39-46_27-05-2022)__rand2341248.sql","","2022-05-27 12:09:46"),
("16","test___(08-40-03_27-05-2022)__rand8836487.sql","","2022-05-27 12:10:03"),
("17","test___(08-40-03_27-05-2022)__rand4160406.sql","","2022-05-27 12:10:03"),
("18","test___(08-40-03_27-05-2022)__rand99604.sql","","2022-05-27 12:10:03"),
("19","test___(08-40-03_27-05-2022)__rand4030298.sql","","2022-05-27 12:10:03"),
("20","test___(08-40-04_27-05-2022)__rand9706577.sql","","2022-05-27 12:10:04"),
("21","test___(08-40-04_27-05-2022)__rand546628.sql","","2022-05-27 12:10:04");




CREATE TABLE `table1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `phone` bigint(15) NOT NULL,
  `Date-Time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `table2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `place` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `order_no` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




